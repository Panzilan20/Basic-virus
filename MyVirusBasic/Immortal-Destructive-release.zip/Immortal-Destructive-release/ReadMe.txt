IIIIIIIIIIIIIIII M           M M           M OOOOOOOOOOOOO RRRRRRRRRR TTTTTTTTTTTTT        A         L
       I         M           M MM         MM O           O R         R      T             A A        L
       I         M M       M M M M       M M O           O R         R      T            A   A       L
       I         M  M     M  M M  M     M  M O           O R         R      T            A   A       L
       I         M   M   M   M M   M   M   M O           O RRRRRRRRRR       T            A   A       L
       I         M    M M    M M    M M    M O           O R                T           AAAAAAA      L
       I         M     M     M M     M     M O           O R R              T          A       A     L
       I         M           M M           M O           O R   R            T         A         A    L
       I         M           M M           M O           O R     R          T        A           A   L
IIIIIIIIIIIIIIII M           M M           M OOOOOOOOOOOOO R       R        T       A             A  LLLLLLLLLLLLLLL

Virus Name:Immortal-Destructive
Create by:Panzilan-2.0peys
App Create:Microsoft Visual Studio code + Command + PowerShell
THIS IS A VIRUS MALWARE NO TPM,NO INSTALL FRAMEWORK !...THIS IS A VIRUS DESTROYED(DESTROY) THE COMPUTER
,I CAN DESTROY YOU SYSTEM AND DELETED WINDOWS C:...YOU CAN'T BOOT AGAIN(WON'T BOOT AGAIN),YOU CAN'T OPEN
TASK MANAGER,CAN'T INSTALL WINDOWS AGAIN(I CAN DELETE YOU HARDWARE),TEXT VIRUS WARNING IS A FILE VBS HERE
(THIS A VIRUS CAN RUNNING IN WINDOWS 8,WINDOWS 8.1,WINDOWS 7,WINDOWS VISTA,
WINDOWS XP,(IF YOU INSTALL FRAMEWORK 3.0)WINDOWS 2000(INSTLL FRAMEWORK 3.0),WINDOWS 10,WINDOWS 11