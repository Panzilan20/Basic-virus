TTTTTTTTTTTTTTTTT  N       N   TTTTTTTTTTTTTTT
        T          NN      N          T
        T          N N     N          T
        T          N  N    N          T               BBBBB      A    TTTTTTTTTT
        T          N   N   N          T               B    B    A A        T
        T          N    N  N          T               BBBBB    AAAAA       T
        T          N     N N          T       .....   B    B  A    A       T
        T          N      NN          T       .   .   BBBBB  A      A      T
        T          N       N          T       .....   
Name:TNT.Bat
Create By:Panzilan 2.0
Made in:C++ + Notepad + Bat
THIS A VIRUS EXPLORER,A VIRUS CAN DELETE ALL FILE "VIRUS CAN DELETE RECYCLE BIN",A VIRUS THEN RESTART
AND YOUR COMPUTER HAS VIRUS MBR BY PANZILAN 2.0 :D
NO WARNING